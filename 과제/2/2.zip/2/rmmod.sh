#!/bin/bash
rmmod dev_driver
rm /dev/dev_driver

