extern int first(int x,int y);

int first(int x, int y)
{
	return x * y;
}

